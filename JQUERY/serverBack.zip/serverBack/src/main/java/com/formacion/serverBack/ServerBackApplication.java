package com.formacion.serverBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerBackApplication.class, args);
	}

}

package com.formacion.pr5WebSocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr5WebSocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
